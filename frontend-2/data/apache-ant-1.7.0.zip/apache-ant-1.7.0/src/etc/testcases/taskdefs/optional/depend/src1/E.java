public class E {
    E() {
        System.out.println(A.class);
    }
}

