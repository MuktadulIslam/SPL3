package org.example;

public class CommandLineDemo {
    PackageExplorer packageExplorer;

    public void startExecFromCmdLine(String[] args) {
        packageExplorer = new PackageExplorer();

        if (args.length == 0) {
            listCommandLineOptions();
            return;
        }

        switch (args[0].toLowerCase()) {
            case "-addproject":
                if (args.length >= 2) {
                    packageExplorer.addNewProjectCmd(args[1]);
                } else {
                    System.out.println("Missing argument: project directory");
                }
                break;

            case "-setrepository":
                if (args.length >= 2) {
                    packageExplorer.setRepoCmd(args[1]);
                } else {
                    System.out.println("Missing argument: repository path");
                }
                break;

            case "-parse":
                if (args.length >= 3) {
                    packageExplorer.parseManualCmd(args[1], args[2]);
                } else {
                    System.out.println("Missing arguments: project directory and freeze label");
                }
                break;

            case "-convertcsvtoarff":
                if (args.length >= 2) {
                    String outputFile = (args.length == 3) ? args[2] : null;
                    packageExplorer.convertCsvToArff(args[1], outputFile);
                } else {
                    System.out.println("Missing argument: CSV file path");
                }
                break;

            case "-predict":
                if (args.length >= 3) {
                    packageExplorer.predict(args[1], args[2]);
                } else {
                    System.out.println("Missing arguments: train file and test file");
                }
                break;

            default:
                listCommandLineOptions();
        }
    }

    public void listCommandLineOptions() {
        System.out.println("Available commands:");
        System.out.println("-addProject projectDirectory");
        System.out.println("-setRepository repoPath");
        System.out.println("-parse projectDirectory freezeLabel");
        System.out.println("-convertCsvToArff csvFilePath [outputFilePath]");
        System.out.println("-predict trainFile testFile");
    }

    public static void main(String[] args) {
        CommandLineDemo cmdDemo = new CommandLineDemo();
        System.out.println("hello");
        cmdDemo.startExecFromCmdLine(args);
    }
}

class PackageExplorer {
    public void addNewProjectCmd(String projectDir) {
        System.out.println("Adding new project: " + projectDir);
    }

    public void setRepoCmd(String repoPath) {
        System.out.println("Setting repository to: " + repoPath);
    }

    public void parseManualCmd(String projectDir, String freezeLabel) {
        System.out.println("Parsing project: " + projectDir + " with freeze label: " + freezeLabel);
    }

    public void convertCsvToArff(String csvFile, String outputFile) {
        if (outputFile == null) {
            System.out.println("Converting CSV to ARFF: " + csvFile);
        } else {
            System.out.println("Converting CSV to ARFF: " + csvFile + ", Output file: " + outputFile);
        }
    }

    public void predict(String trainFile, String testFile) {
        System.out.println("Predicting using train file: " + trainFile + " and test file: " + testFile);
    }
}
