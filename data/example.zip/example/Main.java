package org.example;

import java.beans.BeanProperty;

// Main class to test the Example class
public class Main {
    @Override
    @BeanProperty
    public static void main(String[] args) {
        /* fdkbdf
        fdkjdhdfk

        fbkjhd*/ int x=1;
        System.out.println(x); // print the value of x
    }
}

